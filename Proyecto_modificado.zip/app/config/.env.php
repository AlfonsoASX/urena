<?php
return [
  'app_name' => 'Grupo Ureña Funerarias',
  'dsn'  => 'mysql:host=ganas001.mysql.guardedhost.com;dbname=ganas001_urena;charset=utf8mb4',
  'user' => 'ganas001_urena',
  'pass' => 't*H3q2pb6Kk)',
  'base_url' => '/',
  'debug' => true,
];
